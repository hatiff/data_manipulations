# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sqlite3

df = pd.read_csv('org.csv', encoding='ISO-8859-1')
step = 28
areas = {}
ind = {}
count = 0
for a in df.values[:, 0]:
    count += 1
    if a in areas:
        areas[a] += 1
    else:
        ind[a] = count
        areas[a] = 1
population = [[],[],[],[],[]]
c = True        
for ar in areas.items():
    if ar[0] == 'Afghanistan':
        c = False
    
    if c:
        continue        
    elif ar[1] == 28:
        population[0].append(df.values[ind[ar[0]]-1, 3])
        population[1].append(df.values[ind[ar[0]]+6, 3])
        population[2].append(df.values[ind[ar[0]]+13, 3])
        population[3].append(df.values[ind[ar[0]]+20, 3])
        population[4].append(ar[0])
plt.pie(population[0], radius=10)
plt.axis('equal')

con = sqlite3.connect('new.db')
ccon = con.cursor()
ccon.execute('''CREATE TABLE population
              (region , y5, y10, y15, y18)''')
for pop in range(len(population[0])):
    data = (population[4][pop], 
            population[0][pop],
            population[1][pop],
            population[2][pop],
            population[3][pop])
    sql = ("INSERT INTO population VALUES(?, ?, ?, ?, ?)")
    ccon.execute(sql, data)
con.commit()