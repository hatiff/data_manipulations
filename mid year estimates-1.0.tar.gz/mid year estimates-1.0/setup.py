# -*- coding: utf-8 -*-
from setuptools import setup, find_packages
from os.path import join, dirname

setup(
      name='mid year estimates',
      version='1.0',
      packages=find_packages(),
      install_requires=[
              'numpy',
              'matplotlib',
              'pandas'
              ],
      include_package_data=True
      )
